import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class naivebayes {

	public static void main(String[] args) {
		// args[0] is train
		// args[1] is test
		// args[2] is train2
		// args[3] is test2
		File train = new File(args[0]);
		File test = new File(args[1]);
		File task1 = new File("src\\task1.txt");
		try {
			BufferedWriter result = new BufferedWriter(new FileWriter(task1));

			helper(train, test, result);
			train = new File(args[2]);
			test = new File(args[3]);
			helper(train, test, result);
			result.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void helper(File train, File test, BufferedWriter result) {

		Map<String, Double> blueWords = new HashMap<String, Double>();
		Map<String, Double> redWords = new HashMap<String, Double>();
		double sum_blueWords = 0.0;
		double sum_redWords = 0.0;
		double blue_count = 0.0;
		double red_count = 0.0;
		double vocabulary = 0.0;
		try {
			Scanner trainsc = new Scanner(train);
			while(trainsc.hasNextLine()) {
				String curr_line = trainsc.nextLine();
				String[] curr_content_tmp = curr_line.split("\\t");
				String curr_class = curr_content_tmp[0];
				String[] curr_content = curr_content_tmp[1].split(" ");
				if(curr_class.equalsIgnoreCase("BLUE")) {
					blue_count++;
				} else {
					red_count++;
				}
				for(int i = 1; i < curr_content.length; i++) {
					String curr_word = curr_content[i].toLowerCase();
					if (!blueWords.containsKey(curr_word) 
							&& !redWords.containsKey(curr_word)) {
						vocabulary++;
					}
					if(curr_class.equalsIgnoreCase("BLUE")) {
						sum_blueWords++;
						if(blueWords.containsKey(curr_word)) {
							double oldvalue = blueWords.get(curr_word);
							blueWords.replace(curr_word, 
									(oldvalue+1.0));
						} else {
							blueWords.put(curr_word, 1.0);
						}
					} else {
						sum_redWords++;
						if(redWords.containsKey(curr_word)) {
							double oldvalue = redWords.get(curr_word);
							redWords.replace(curr_word, 
									(oldvalue+1.0));
						} else {
							redWords.put(curr_word, 1.0);
						}
					}
				}
			}
			trainsc.close();
		} catch (IOException e) {
			System.out.println("Error Openning Trainning File!");
			e.printStackTrace();
		}
		//		System.out.println(vocabulary);
		//		System.out.println(blueWords.size());
		//		System.out.println(redWords.size());
		//		System.out.println(sum_blueWords);
		for(Map.Entry<String, Double> eachEntry : blueWords.entrySet()) {
			eachEntry.setValue((eachEntry.getValue() + 1.0) / 
					(sum_blueWords + vocabulary));
		}
		for(Map.Entry<String, Double> eachEntry : redWords.entrySet()) {
			eachEntry.setValue((eachEntry.getValue() + 1.0) / 
					(sum_redWords + vocabulary));
		}

		double prior_blue = blue_count / (blue_count + red_count);
		double prior_red = red_count / (blue_count + red_count);

		double log_prob_blue = Math.log(prior_blue);
		double log_prob_red = Math.log(prior_red);
		double correctness = 0.0;
		double corr_red = 0.0;
		double corr_blue = 0.0;
		double false_red = 0.0;
		double false_blue = 0.0;
		double count = 0.0;
		double unseen_blue = 1.0 / (sum_blueWords + vocabulary);
		double unseen_red = 1.0 / (sum_redWords + vocabulary);
		try {
			Scanner testsc = new Scanner(test);
			while(testsc.hasNextLine()) {
				count++;
				String curr_line_test = testsc.nextLine();
				String[] curr_content_tmp_test = curr_line_test.split("\\t");
				String curr_class_test = curr_content_tmp_test[0];
				String[] curr_content_test = curr_content_tmp_test[1].split(" ");
				// System.out.println(curr_class_test);
				log_prob_blue = Math.log(prior_blue);
				log_prob_red = Math.log(prior_red);
				for(int i = 1; i < curr_content_test.length; i++) {
					String curr_word = curr_content_test[i].toLowerCase();
					curr_word = curr_word.toLowerCase();
					// Blue
					if(blueWords.containsKey(curr_word)) {
						log_prob_blue += Math.log(blueWords.get(curr_word));
					} else /*if(redWords.containsKey(curr_word))*/{
						log_prob_blue += Math.log(unseen_blue);
					} 
					// Red
					if(redWords.containsKey(curr_word)) {
						log_prob_red += Math.log(redWords.get(curr_word));
					} else /*if(conWords.containsKey(curr_word))*/{
						log_prob_red += Math.log(unseen_red);
					}
				}
				if(log_prob_blue >= log_prob_red) {
					if(curr_class_test.equalsIgnoreCase("BLUE")) {
						correctness++;
						corr_blue++;
					} else {
						false_blue++;
					}
					// System.out.println("C");
				} else {
					if(curr_class_test.equalsIgnoreCase("RED")) {
						correctness++;
						corr_red++;
					} else {
						false_red++;
					}
					// System.out.println("L");
				}
			}
			result.write("overall accuracy\n" + String.format("%.4f\n", (correctness / count)));
			result.write("precision for red\n"+ String.format("%.4f\n", (corr_red / (corr_red + false_red))));
			result.write("recall for red\n"+ String.format("%.4f\n", (corr_red / (corr_red + false_blue))));
			result.write("precision for blue\n"+ String.format("%.4f\n", (corr_blue / (corr_blue + false_blue))));
			result.write("recall for blue\n"+ String.format("%.4f\n\n", (corr_blue / (corr_blue + false_red))));
			testsc.close();
		} catch (IOException e) {
			System.out.println("Error Openning Test File!");
			e.printStackTrace();
		}
	}

}
